package com.lycan.fantasybachelor;

import com.google.devtools.simple.runtime.components.Component;
import com.google.devtools.simple.runtime.components.HandlesEventDispatching;
import com.google.devtools.simple.runtime.components.android.Button;
import com.google.devtools.simple.runtime.components.android.HorizontalArrangement;
import com.google.devtools.simple.runtime.components.android.Label;
import com.google.devtools.simple.runtime.events.EventDispatcher;

/*
 * A specific league's home screen
 */

public class LeagueActivity extends MainMenuActivity implements HandlesEventDispatching {

	
	// UI Component Declarations
	private Button mainMenuBtn;
	private Label  headerLbl;
	private Button settingsBtn;
	private Label  adminLbl;
	private Label  space3Lbl;
	private Label  titleLbl;
	private Label  space5Lbl;
	private Button myPicksBtn;
	private Button standingsBtn;
	private Button weeklyBDBtn;
	private Button leaguePicksBtn;
	private Button messageBoardBtn;
	private Label  space9Lbl;
	private Button rulesBtn;
	
	// Variables
	
	void $define() {
		
		setTitle("Fantasy Bachelor");
		
		// Designer: Create UI components and set their properties
		
		HorizontalArrangement hr1 = new HorizontalArrangement(this);
		mainMenuBtn = new Button(hr1, "Main Menu");
		headerLbl   = new Label(hr1, "Fantasy Bachelor Header");
		settingsBtn = new Button(hr1, "Settings");
		
		HorizontalArrangement hr2 = new HorizontalArrangement(this);
		adminLbl = new Label(hr2, "Admin Notifications");
		
		HorizontalArrangement hr3s = new HorizontalArrangement(this);
		space3Lbl = new Label(hr3s, " ");
		
		HorizontalArrangement hr4 = new HorizontalArrangement(this);
		titleLbl = new Label(hr4, "League Name");
		
		HorizontalArrangement hr5s = new HorizontalArrangement(this);
		space5Lbl = new Label(hr5s, " ");
		
		HorizontalArrangement hr6 = new HorizontalArrangement(this);
		myPicksBtn = new Button(hr6, "My Picks");
		
		HorizontalArrangement hr7 = new HorizontalArrangement(this);
		standingsBtn = new Button(hr7, "Standings");
		
		HorizontalArrangement hr8 = new HorizontalArrangement(this);
		weeklyBDBtn = new Button(hr8, "Weekly Breadown");
		
		HorizontalArrangement hr9 = new HorizontalArrangement(this);
		leaguePicksBtn = new Button(hr9, "League Picks");
		
		HorizontalArrangement hr10 = new HorizontalArrangement(this);
		messageBoardBtn = new Button(hr10, "Message Board");
		
		HorizontalArrangement hr11s = new HorizontalArrangement(this);
		space9Lbl = new Label(hr11s, " ");
		
		HorizontalArrangement hr12 = new HorizontalArrangement(this);
		rulesBtn = new Button(hr12, "Rules");
		
		EventDispatcher.registerEventForDelegation(this, "FantasyBachelor", "Click");
	} // $define()
	
	@Override
	public boolean dispatchEvent(Component component, String id, String eventName,
		Object[] args) {
		
		// Go to main menu
		if (component.equals(mainMenuBtn) && eventName.equals("Click")) {
			startNewForm("MainMenuActivity", "blah");
			return true;
		}
		
		// Go to settings
		else if (component.equals(settingsBtn) && eventName.equals("Click")) {
			startNewForm("SettingsActivity", "blah");
			return true;
		}
		
		// Go to my picks
		else if (component.equals(myPicksBtn) && eventName.equals("Click")) {
			startNewForm("MyPicksActivity", "blah");
			return true;
		}
		
		// Go to league standings
		else if (component.equals(standingsBtn) && eventName.equals("Click")) {
			startNewForm("StandingsActivity", "blah");
			return true;
		}
		
		// Go to weekly breakdown
		else if (component.equals(weeklyBDBtn) && eventName.equals("Click")) {
			startNewForm("WeeklyBDActivity", "blah");
			return true;
		}
		
		// Go to league picks
		else if (component.equals(leaguePicksBtn) && eventName.equals("Click")) {
			startNewForm("LeaguePicksActivity", "blah");
			return true;
		}
		
		// Go to message board
		else if (component.equals(messageBoardBtn) && eventName.equals("Click")) {
			startNewForm("MessageBoardActivity", "blah");
			return true;
		}
		
		// Go to rules
		else if (component.equals(rulesBtn) && eventName.equals("Click")) {
			startNewForm("RulesActivity", "blah");
			return true;
		}
		
		return false;
	} // dispatchEvent
	
} // class
