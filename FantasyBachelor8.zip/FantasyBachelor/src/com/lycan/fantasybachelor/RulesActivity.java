package com.lycan.fantasybachelor;

import com.google.devtools.simple.runtime.components.Component;
import com.google.devtools.simple.runtime.components.HandlesEventDispatching;
import com.google.devtools.simple.runtime.components.android.Button;
import com.google.devtools.simple.runtime.components.android.HorizontalArrangement;
import com.google.devtools.simple.runtime.components.android.Label;
import com.google.devtools.simple.runtime.events.EventDispatcher;


/*
 * Display and change/add rules
 */

public class RulesActivity extends LeagueActivity implements HandlesEventDispatching {

	
	// UI Component Declarations
	private Button leagueBtn;
	private Label  headerLbl;
	private Button settingsBtn;
	private Label  space2Lbl;
	private Label  titleLbl;
	private Label  space4Lbl;
	private Label  rulesLbl;
	private Label  space6Lbl;
	private Button changeRulesBtn;
	
	// Variables
	
	void $define() {
		
		setTitle("Fantasy Bachelor");
		
		// Designer: Create UI components and set their properties
		
		HorizontalArrangement hr1 = new HorizontalArrangement(this);
		leagueBtn   = new Button(hr1, "League");
		headerLbl   = new Label(hr1, "Fantasy Bachelor Header");
		settingsBtn = new Button (hr1, "Settings");
		
		HorizontalArrangement hr2s = new HorizontalArrangement(this);
		space2Lbl = new Label(hr2s, " ");
		
		HorizontalArrangement hr3 = new HorizontalArrangement(this);
		titleLbl = new Label(hr3, "Game Rules");
		
		HorizontalArrangement hr4s = new HorizontalArrangement(this);
		space4Lbl = new Label(hr4s, " ");
		
		HorizontalArrangement hr5 = new HorizontalArrangement(this);
		rulesLbl = new Label(hr5, "These are the rules of the game...");
		
		HorizontalArrangement hr6s = new HorizontalArrangement(this);
		space6Lbl = new Label(hr6s, " ");
		
		HorizontalArrangement hr7 = new HorizontalArrangement(this);
		changeRulesBtn = new Button(hr7, "Adjust/Add Own Rule");
		
		
		EventDispatcher.registerEventForDelegation(this, "FantasyBachelor", "Click");
	} // $define()
	
	@Override
	public boolean dispatchEvent(Component component, String id, String eventName,
		Object[] args) {
		
		// Go back to league
		if (component.equals(leagueBtn) && eventName.equals("Click")) {
			startNewForm("LeagueActivity", "blah");
			return true;
		}
		
		// Go to settings
		else if (component.equals(settingsBtn) && eventName.equals("Click")) {
			startNewForm("SettingsActivity", "blah");
			return true;
		}
		
		// Change a rule
		else if (component.equals(changeRulesBtn) && eventName.equals("Click")) {
			
			return true;
		}
		
		return false;
	} // dispatchEvent
	
} // class
