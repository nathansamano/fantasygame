package com.lycan.fantasybachelor;

import com.google.devtools.simple.runtime.components.Component;
import com.google.devtools.simple.runtime.components.HandlesEventDispatching;
import com.google.devtools.simple.runtime.components.android.Button;
import com.google.devtools.simple.runtime.components.android.HorizontalArrangement;
import com.google.devtools.simple.runtime.components.android.Label;
import com.google.devtools.simple.runtime.components.android.Notifier;
import com.google.devtools.simple.runtime.components.android.PasswordTextBox;
import com.google.devtools.simple.runtime.components.android.TextBox;
import com.google.devtools.simple.runtime.events.EventDispatcher;
import com.lycan.fantasybachelor.RegisterActivity.SLList.Account;

/* 
 * Register an account to log in with
 */

public class RegisterActivity extends MainMenuActivity implements HandlesEventDispatching {

	
	// UI Component Declarations
	private Button           backBtn;
	private Label            headerLbl;
	private Button           settingsBtn;
	private Label            space2Lbl;
	private Label            titleLbl;
	private TextBox          usrNameTB;
	private TextBox          emailTB;
	private PasswordTextBox  accountPasswdTB;
	private PasswordTextBox  confirmPasswdTB;
	private Button           createAccountBtn;
	private Notifier note = new Notifier(this);
	
	// Variables
	
	public class SLList {
		
		// nodes are of type Account
		public class Account {
			// payload
			String usrName;
			String email;
			String passwd;
			// pointer to next node
			Account next;
			
			// Zero argument constructor for generic Account
			public Account() {
				usrName = "";
				email   = "";
				passwd  = "";
				next    = null;
			}
			
			// Construct an Account with said username, email, and password
			public Account(String newUsrName, String newEmail, String newPasswd) {
				usrName = newUsrName;
				email   = newEmail;
				passwd  = newPasswd;
			}
			
			// Print the contents of an Account
			public String printAccount() {
				String str = new String("Account: " + usrName + " " + email + " " + passwd + "\n");
				return str;
			}
		} // Account
		
		// Data members for SLList
		int n = 0;				// number of nodes in the list
		Account head = null;	// first in list
		Account tail = null;	// last in list
		
		// Return the number of nodes in the list
		public int size() {
			return n;
		}
		
		// Return said list
		public SLList getList() {
			return this;
		}
		
		// Print the contents of the entire list
		public String printList() {
			String str = new String();
			Account u = new Account();
			u = head;
			while (u != null) {
				str = str + u.printAccount();
				u = u.next;
			}
			return str;
		}
		
		// add an account to the list
		public boolean add(String newUsrName, String newEmail, String newPasswd) {
			Account u = new Account(newUsrName, newEmail, newPasswd);
			if (n == 0) head = u;
			else tail.next = u;
			tail = u;
			n++;
			return true;
		}
		
		// fetch an account by email matching user input
		public String fetchByEmail() {
			Account u,p = new Account();
			u = head;
			while (u != null) {
				if (u.email.equals(emailTB.Text())) p = u;
				u = u.next;
			}
			return p.email;
		}
		
		// update an account
		// delete an account
		
	} // SLList
	
	
	// create a SLList to hold all accounts on system
	SLList masterList = new SLList();
	
	void $define() {
		
		setTitle("Fantasy Bachelor");
		
		// Designer: Create UI components and set their properties
		
		HorizontalArrangement hr1 = new HorizontalArrangement(this);
		backBtn = new Button(hr1, "Go Back");
		headerLbl   = new Label(hr1, "Fantasy Bachelor Header");
		settingsBtn = new Button(hr1, "Settings");
		
		HorizontalArrangement hr2s = new HorizontalArrangement(this);
		space2Lbl = new Label(hr2s, " ");
		
		HorizontalArrangement hr3 = new HorizontalArrangement(this);
		titleLbl = new Label(hr3, "Create an Account");
		
		HorizontalArrangement hr4 = new HorizontalArrangement(this);
		usrNameTB = new TextBox(hr4, "", LENGTH_FILL_PARENT);
		usrNameTB.Hint("Create Username");
		
		HorizontalArrangement hr5 = new HorizontalArrangement(this);
		emailTB = new TextBox(hr5, "", LENGTH_FILL_PARENT);
		emailTB.Hint("Email");
		
		HorizontalArrangement hr6 = new HorizontalArrangement(this);
		accountPasswdTB = new PasswordTextBox(hr6);
		accountPasswdTB.Width(LENGTH_FILL_PARENT);
		accountPasswdTB.Hint("Create Account Password");
		
		HorizontalArrangement hr7 = new HorizontalArrangement(this);
		confirmPasswdTB = new PasswordTextBox(hr7);
		confirmPasswdTB.Width(LENGTH_FILL_PARENT);
		confirmPasswdTB.Hint("Confirm Account Password");
		
		HorizontalArrangement hr8 = new HorizontalArrangement(this);
		createAccountBtn = new Button(hr8, "Create Account");
		
		EventDispatcher.registerEventForDelegation(this, "FantasyBachelor", "Click");
	} // $define()
	
	@Override
	public boolean dispatchEvent(Component component, String id, String eventName,
		Object[] args) {
		
		// Return to login screen
		if (component.equals(backBtn) && eventName.equals("Click")) {
			startNewForm("FantasyBachelorActivity", "blah");
			return true;
		}
		
		// Go to settings
		else if (component.equals(settingsBtn) && eventName.equals("Click")) {
			startNewForm("SettingsActivity", "blah");
			return true;
		}
		
		// Create an account
		else if (component.equals(createAccountBtn) && eventName.equals("Click")) {
			// all fields empty
			if (usrNameTB.Text().equals("") || emailTB.Text().equals("") || accountPasswdTB.Text().equals("") || confirmPasswdTB.Text().equals("")
				|| !confirmPasswdTB.Text().equals(accountPasswdTB.Text())) {
				
				// passwords don't match
				if (!confirmPasswdTB.Text().equals(accountPasswdTB.Text())) {
					note.ShowAlert("Passwords do not match");
				}
				
				return false;
			} 
			
			else {

				// if email address already has an account on file
				if (masterList.fetchByEmail().equals(emailTB.Text())) {
					note.ShowAlert("Email already exists");
					return false;
				}
				
				// create/add an account to masterList matching user input
				masterList.add(usrNameTB.Text(), emailTB.Text(), accountPasswdTB.Text());
			
				//titleLbl.Text("List: " + masterList.printList() + "Fetch email: " + masterList.fetchByEmail());
				//startNewForm("MainMenuActivity", "blah");
				return true;
			}
			
		} // createAccountBtn
		
		return false;
	} // dispatchEvent
	
} // class

