package com.lycan.fantasybachelor;

import com.google.devtools.simple.runtime.components.Component;
import com.google.devtools.simple.runtime.components.HandlesEventDispatching;
import com.google.devtools.simple.runtime.components.android.Button;
import com.google.devtools.simple.runtime.components.android.HorizontalArrangement;
import com.google.devtools.simple.runtime.components.android.Label;
import com.google.devtools.simple.runtime.components.android.PasswordTextBox;
import com.google.devtools.simple.runtime.components.android.TextBox;
import com.google.devtools.simple.runtime.events.EventDispatcher;

/*
 *  Create a league for people to join
 */

public class CreateLeagueActivity extends MainMenuActivity implements HandlesEventDispatching {

	
	// UI Component Declarations
	private Button           mainMenuBtn;
	private Label            headerLbl;
	private Button           settingsBtn;
	private Label            space2Lbl;
	private Label            titleLbl;
	private TextBox          leagueNameTB;
	private PasswordTextBox  leaguePasswdTB;
	private PasswordTextBox  confirmPasswdTB;
	private Button           createLeagueBtn;
	
	// Variables
	
	void $define() {
		
		setTitle("Fantasy Bachelor");
		
		// Designer: Create UI components and set their properties
		
		HorizontalArrangement hr1 = new HorizontalArrangement(this);
		mainMenuBtn = new Button(hr1, "Main Menu");
		headerLbl   = new Label(hr1, "Fantasy Bachelor Header");
		settingsBtn = new Button(hr1, "Settings");
		
		HorizontalArrangement hr2s = new HorizontalArrangement(this);
		space2Lbl = new Label(hr2s, " ");
		
		HorizontalArrangement hr3 = new HorizontalArrangement(this);
		titleLbl = new Label(hr3, "Create a League");
		
		HorizontalArrangement hr4 = new HorizontalArrangement(this);
		leagueNameTB = new TextBox(hr4, "", LENGTH_FILL_PARENT);
		leagueNameTB.Hint("League Name");
		
		HorizontalArrangement hr5 = new HorizontalArrangement(this);
		leaguePasswdTB = new PasswordTextBox(hr5);
		leaguePasswdTB.Width(LENGTH_FILL_PARENT);
		leaguePasswdTB.Hint("League Password");
		
		HorizontalArrangement hr6 = new HorizontalArrangement(this);
		confirmPasswdTB = new PasswordTextBox(hr6);
		confirmPasswdTB.Width(LENGTH_FILL_PARENT);
		confirmPasswdTB.Hint("Confirm League Password");
		
		HorizontalArrangement hr7 = new HorizontalArrangement(this);
		createLeagueBtn = new Button(hr7, "Create League");
		
		EventDispatcher.registerEventForDelegation(this, "FantasyBachelor", "Click");
	} // $define()
	
	@Override
	public boolean dispatchEvent(Component component, String id, String eventName,
		Object[] args) {
		
		// Go to main menu
		if (component.equals(mainMenuBtn) && eventName.equals("Click")) {
			startNewForm("MainMenuActivity", "blah");
			return true;
		}
		
		// Go to settings
		else if (component.equals(settingsBtn) && eventName.equals("Click")) {
			startNewForm("SettingsActivity", "blah");
			return true;
		}
		
		// Create a league with set credentials
		else if (component.equals(createLeagueBtn) && eventName.equals("Click")) {
			startNewForm("NewLeagueActivity", "blah");
			return true;
		}
		
		return false;
	} // dispatchEvent
	
} // class