package com.lycan.fantasybachelor;

import com.google.devtools.simple.runtime.components.Component;
import com.google.devtools.simple.runtime.components.HandlesEventDispatching;
import com.google.devtools.simple.runtime.components.android.Button;
import com.google.devtools.simple.runtime.components.android.HorizontalArrangement;
import com.google.devtools.simple.runtime.components.android.Label;
import com.google.devtools.simple.runtime.events.EventDispatcher;
import com.lycan.fantasybachelor.RegisterActivity.SLList;


/*
 * Fake database to store all user data here for testing
 */

public class FakeDBActivity extends FantasyBachelorActivity implements HandlesEventDispatching {

	
	// UI Component Declarations
	
	// Variables
	
	//SLList registerList = new SLList();
	
	void $define() {
		
		// Designer: Create UI components and set their properties
		
		
		EventDispatcher.registerEventForDelegation(this, "FantasyBachelor", "Click");
	} // $define()
	
	@Override
	public boolean dispatchEvent(Component component, String id, String eventName,
		Object[] args) {
		
		
		
		return false;
	} // dispatchEvent
	
} // class

