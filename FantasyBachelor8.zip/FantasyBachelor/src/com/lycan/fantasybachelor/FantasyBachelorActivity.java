package com.lycan.fantasybachelor;

import com.google.devtools.simple.runtime.components.android.Button;
import com.google.devtools.simple.runtime.components.android.Form;
import com.google.devtools.simple.runtime.components.android.HorizontalArrangement;
import com.google.devtools.simple.runtime.components.android.Label;
import com.google.devtools.simple.runtime.components.android.PasswordTextBox;
import com.google.devtools.simple.runtime.components.android.TextBox;
import com.google.devtools.simple.runtime.components.Component;
import com.google.devtools.simple.runtime.components.HandlesEventDispatching;
import com.google.devtools.simple.runtime.events.EventDispatcher;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

/* FantasyBachelor: 
 * 
 * Nathan Samano
 * Begun 4 September 2014
 * Version current as of 16 October 2014
 */

public class FantasyBachelorActivity extends Form implements HandlesEventDispatching {

	// UI Component Declarations
	
	private Label            titleLbl;
	private TextBox          usrNameBox;
	private PasswordTextBox  passwdTB;
	private Button           signInBtn;
	private Button           regBtn;
	private Button           fbBtn;
	
	// Variables
	
	// Java Bridger main() set the layout of the screen
	void $define()  {
		
		setTitle("Fantasy Bachelor");
		
		// Designer: Create UI components and set their properties
		
		// Display title of the screen
		HorizontalArrangement hr1 = new HorizontalArrangement(this, LENGTH_FILL_PARENT);
		titleLbl = new Label(hr1,"\n\n\nFantasy Bachelor",LENGTH_FILL_PARENT,COLOR_BLACK);
		titleLbl.FontSize(32);
		//titleLbl.Position(ALIGNMENT_CENTER);
				
		// int bl = Form.LENGTH_FILL_PARENT - test.Width()/2;
		
		// Text box for username input
		HorizontalArrangement hr2 = new HorizontalArrangement(this);
		usrNameBox = new TextBox(hr2, "", LENGTH_FILL_PARENT);
		usrNameBox.Hint("Username");
		
		// Text box for password input
		HorizontalArrangement hr3 = new HorizontalArrangement(this);
		passwdTB = new PasswordTextBox(hr3);
		passwdTB.Width(LENGTH_FILL_PARENT);
		passwdTB.Hint("Password");
		
		//Test to see what the Width of the screen is. Result is 0. Something is wrong.
		//String a = String.valueOf(hr2.Width()/*Width()*/);
		//test.Text(a);
		
		// Create sign in and register buttons
		HorizontalArrangement hr4 = new HorizontalArrangement(this);
		signInBtn = new Button(hr4, "Sign In");
		regBtn    = new Button(hr4, "Register");
		
		// Create login with Facebook button
		HorizontalArrangement hr5 = new HorizontalArrangement(this);
		fbBtn = new Button(hr5, "Login with Facebook");

		
		
		// Let the runtime system know which events to report to the dispatcher.  
		// By the second argument can be any string.    The third argument must
	    // exactly match the name of the event that you want to handle for that component.
		// When the event happens, dispatchEvent will be called with these arguments.
		
		EventDispatcher.registerEventForDelegation(this, "FantasyBachelor", "Initialize");
		EventDispatcher.registerEventForDelegation(this, "FantasyBachelor", "Click");
	} // $define()
	
	// Events: Override the method for the Form superclass
	@Override
	public boolean dispatchEvent(Component component, String id, String eventName,
			Object[] args) {
		
		
		
		// if initialized event is triggered
		/*if (component.equals(this) && eventName.equals("Intialize")) {
			startNewForm("LoginActivity", "blah");
			return true;
		}*/
		
		// Go to Main Menu Screen
		if (component.equals(signInBtn) && eventName.equals("Click")) {
			startNewForm("MainMenuActivity", "blah");
			return true;
		}
		
		// Go to Registration
		if (component.equals(regBtn) && eventName.equals("Click")) {
			startNewForm("RegisterActivity", "blah");
			return true;
		}
		
		// Login with Facebook
		if (component.equals(fbBtn) && eventName.equals("Click")){
			return true;
		}
		
		// return false if the event was not dispatched
		return false;
	} // dispatchEvent

} // class