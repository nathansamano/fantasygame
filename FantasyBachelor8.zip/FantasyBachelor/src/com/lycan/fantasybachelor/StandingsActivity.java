package com.lycan.fantasybachelor;

import com.google.devtools.simple.runtime.components.Component;
import com.google.devtools.simple.runtime.components.HandlesEventDispatching;
import com.google.devtools.simple.runtime.components.android.Button;
import com.google.devtools.simple.runtime.components.android.HorizontalArrangement;
import com.google.devtools.simple.runtime.components.android.Label;
import com.google.devtools.simple.runtime.events.EventDispatcher;

/*
 * Display league standings
 */

public class StandingsActivity extends LeagueActivity implements HandlesEventDispatching {

	
	// UI Component Declarations
	private Button leagueBtn;
	private Label  headerLbl;
	private Button settingsBtn;
	private Label  space2Lbl;
	private Label  titleLbl;
	private Label  space4Lbl;
	
	
	// Variables
	private int numPlayers = 5;							// hard coded players for testing purposes
	private Label[] players = new Label[numPlayers];	// array of players in the league
	
	void $define() {
		
		setTitle("Fantasy Bachelor");
		
		// Designer: Create UI components and set their properties
		
		HorizontalArrangement hr1 = new HorizontalArrangement(this);
		leagueBtn   = new Button(hr1, "League");
		headerLbl   = new Label(hr1, "Fantasy Bachelor Header");
		settingsBtn = new Button (hr1, "Settings");
		
		HorizontalArrangement hr2s = new HorizontalArrangement(this);
		space2Lbl = new Label(hr2s, " ");
		
		HorizontalArrangement hr3 = new HorizontalArrangement(this);
		titleLbl = new Label(hr3, "Standings");
		
		HorizontalArrangement hr4s = new HorizontalArrangement(this);
		space4Lbl = new Label(hr4s, " ");
		
		int score = 0;
		for (int i = 0; i < numPlayers; i++){
			HorizontalArrangement hr = new HorizontalArrangement(this);
			players[i] = new Label(hr);
			players[i].Text("Player's Name " + score + " pts");
		}
		
		
		EventDispatcher.registerEventForDelegation(this, "FantasyBachelor", "Click");
	} // $define()
	
	@Override
	public boolean dispatchEvent(Component component, String id, String eventName,
		Object[] args) {
		
		// Go back to league
		if (component.equals(leagueBtn) && eventName.equals("Click")) {
			startNewForm("LeagueActivity", "blah");
			return true;
		}
		
		// Go to settings
		else if (component.equals(settingsBtn) && eventName.equals("Click")) {
			startNewForm("SettingsActivity", "blah");
			return true;
		}
		
		return false;
	} // dispatchEvent
	
} // class

