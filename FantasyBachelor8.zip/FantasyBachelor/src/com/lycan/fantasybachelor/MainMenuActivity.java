package com.lycan.fantasybachelor;

import com.google.devtools.simple.runtime.components.android.Button;
import com.google.devtools.simple.runtime.components.android.Form;
import com.google.devtools.simple.runtime.components.android.HorizontalArrangement;
import com.google.devtools.simple.runtime.components.android.Label;
import com.google.devtools.simple.runtime.components.android.TextBox;
import com.google.devtools.simple.runtime.components.Component;
import com.google.devtools.simple.runtime.components.HandlesEventDispatching;
import com.google.devtools.simple.runtime.events.EventDispatcher;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

/* 
 * Main Menu screen for a given account
 */

public class MainMenuActivity extends FantasyBachelorActivity implements HandlesEventDispatching {

	// UI Component Declarations
	private Button signOutBtn;
	private Label  headerLbl;
	private Label  mainMenuLbl;
	private Button settingsBtn;
	private Label  space2Lbl;
	private Label  myLeaguesLbl;
	private Button league1Btn;
	private Label  space5Lbl;
	private Button joinLeagueBtn;
	private Button createLeagueBtn;
	private Label  space7Lbl;
	private Label  newsLbl;
	private Label  apiLbl;
	
	// Variables
	
	// Java Bridger main()
	void $define() {
		
		setTitle("Fantasy Bachelor");
		
		// Designer: Create UI components and set their properties
		
		HorizontalArrangement hr1 = new HorizontalArrangement(this, LENGTH_FILL_PARENT);
		signOutBtn  = new Button(hr1, "Sign Out");
		headerLbl   = new Label(hr1,"Fantasy Bachelor Header");
		settingsBtn = new Button(hr1, "Settings");
		
		HorizontalArrangement hr2s = new HorizontalArrangement(this);
		space2Lbl = new Label(hr2s," ");
		space2Lbl.FontSize(32);
		
		HorizontalArrangement hr3 = new HorizontalArrangement(this);
		myLeaguesLbl = new Label(hr3, "My Leagues");
		
		HorizontalArrangement hr4 = new HorizontalArrangement(this);
		league1Btn = new Button(hr4, "League 1 Name");
		
		HorizontalArrangement hr5s = new HorizontalArrangement(this);
		space5Lbl = new Label(hr5s, " ");
		space5Lbl.FontSize(20);
		
		HorizontalArrangement hr6 = new HorizontalArrangement(this);
		joinLeagueBtn  = new Button(hr6, "Join a League");
		createLeagueBtn = new Button(hr6, "Create a League");
		
		HorizontalArrangement hr7s = new HorizontalArrangement(this);
		space7Lbl = new Label(hr7s, " ");
		space7Lbl.FontSize(20);
		
		HorizontalArrangement hr8 = new HorizontalArrangement(this);
		newsLbl = new Label(hr8, "News");
		
		HorizontalArrangement hr9 = new HorizontalArrangement(this);
		apiLbl = new Label(hr9, "This space allocated for api news");
		
	
		
		EventDispatcher.registerEventForDelegation(this, "FantasyBachelor", "Click");
	} // $define()
	
	// Events: Override the method for the Form superclass
	@Override
	public boolean dispatchEvent(Component component, String id, String eventName,
			Object[] args) {
		
		// Go to a league's screen
		if (component.equals(league1Btn) && eventName.equals("Click")) {
			startNewForm("LeagueActivity", "blah");
			return true;
		}
		
		// Go to join league screen
		else if (component.equals(joinLeagueBtn) && eventName.equals("Click")) {
			startNewForm("JoinLeagueActivity", "blah");
			return true;
		}
		
		// Go to create league screen
		else if (component.equals(createLeagueBtn) && eventName.equals("Click")) {
			startNewForm("CreateLeagueActivity", "blah");
			return true;
		}
		
		// Sign out and return to login screen
		else if (component.equals(signOutBtn) && eventName.equals("Click")) {
			startNewForm("FantasyBachelorActivity", "blah");
			return true;
		}
		
		// Go to settings
		else if (component.equals(settingsBtn) && eventName.equals("Click")) {
			startNewForm("SettingsActivity", "blah");
			return true;
		}
		
		
		// return false if the event was not dispatched
		return false;
	} // dispatchEvent

} // class