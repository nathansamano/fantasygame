package com.lycan.fantasybachelor;

import com.google.devtools.simple.runtime.components.Component;
import com.google.devtools.simple.runtime.components.HandlesEventDispatching;
import com.google.devtools.simple.runtime.components.android.Button;
import com.google.devtools.simple.runtime.components.android.HorizontalArrangement;
import com.google.devtools.simple.runtime.components.android.Label;
import com.google.devtools.simple.runtime.events.EventDispatcher;

/*
 * View league members' picks for a given week
 */

public class LeaguePicksActivity extends LeagueActivity implements HandlesEventDispatching {

	
	// UI Component Declarations
	private Button     leagueBtn;
	private Label      headerLbl;
	private Button     settingsBtn;
	private Label      space2Lbl;
	private Label      titleLbl;
	private Label      space4Lbl;
	private Label      space6Lbl;
	
	
	// Variables
	private final int ROWS    = 2;
	private final int COLUMNS = 4;
	private int numPlayers = 5;
	private int numWeeks = 8;
	private Label[] players = new Label[numPlayers];			// array of labels for each contestant
	private Button[][] week = new Button[ROWS][COLUMNS];		// array of buttons for each week
	
	void $define() {
		
		setTitle("Fantasy Bachelor");
		
		// Designer: Create UI components and set their properties
		
		HorizontalArrangement hr1 = new HorizontalArrangement(this);
		leagueBtn   = new Button(hr1, "League");
		headerLbl   = new Label(hr1, "Fantasy Bachelor Header");
		settingsBtn = new Button (hr1, "Settings");
		
		HorizontalArrangement hr2s = new HorizontalArrangement(this);
		space2Lbl = new Label(hr2s, " ");
		
		HorizontalArrangement hr3 = new HorizontalArrangement(this);
		titleLbl = new Label(hr3, "League Picks");
		
		HorizontalArrangement hr4s = new HorizontalArrangement(this);
		space4Lbl = new Label(hr4s, " ");
		
		////////////////////////////////////////////////////////////////
		
		int weekNum = 1;
		for (int i = 0; i < ROWS; i++){
			HorizontalArrangement hr = new HorizontalArrangement(this);
			for (int j = 0; j < COLUMNS; j++) {
				week[i][j] = new Button(hr);
				week[i][j].Text("Week " + weekNum++);
			}
		}
		
		////////////////////////////////////////////////////////////////
		
		HorizontalArrangement hr6s = new HorizontalArrangement(this);
		space6Lbl = new Label(hr6s, " ");
		
		String picks = "Picks";
		for (int i = 0; i < numPlayers; i++){
			HorizontalArrangement hr = new HorizontalArrangement(this);
			players[i] = new Label(hr);
			players[i].Text("Player's Name " + picks);
		}
		
		
		EventDispatcher.registerEventForDelegation(this, "FantasyBachelor", "Click");
	} // $define()
	
	@Override
	public boolean dispatchEvent(Component component, String id, String eventName,
		Object[] args) {
		
		// Go back to league
		if (component.equals(leagueBtn) && eventName.equals("Click")) {
			startNewForm("LeagueActivity", "blah");
			return true;
		}
		
		// Go to settings
		else if (component.equals(settingsBtn) && eventName.equals("Click")) {
			startNewForm("SettingsActivity", "blah");
			return true;
		}
		
		// Test code that gives output when a week is clicked
		for (int i = 0; i < ROWS; i++)
			for (int j = 0; j < COLUMNS; j++) {
				if (component.equals(week[i][j]) && eventName.equals("Click")) {
					week[i][j].BackgroundColor(COLOR_RED);
					return true;
				}
			}
		
		return false;
	} // dispatchEvent
	
} // class


